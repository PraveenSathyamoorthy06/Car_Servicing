package com.cognizant.carservice.exception;

public interface ICarServiceMessage {

	public String DRIVER = "Driver missing!!!";
	public String SQL = "Database error!!!";
	public String CONTACT = "Contact admin for solution";
	public String REGISTER = "Error on registration Contact admin";
	public String CLOSING_RESOURCE = "Error while closing resource Contact admin";

}
