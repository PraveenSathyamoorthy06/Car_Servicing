package com.cognizant.carservice.dao;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.carservice.exception.CarServiceException;
import com.cognizant.carservice.model.ICarService;
import com.cognizant.carservice.model.LoginDetails;
import com.cognizant.carservice.model.SecurityQuestion;
import com.cognizant.carservice.model.ServiceCentre;
import com.cognizant.carservice.model.ServiceHistory;
import com.cognizant.carservice.model.ServicePayment;
import com.cognizant.carservice.model.ServiceRequest;
import com.cognizant.carservice.model.ServiceSet;
import com.cognizant.carservice.model.ServiceType;
import com.cognizant.carservice.model.UserDetails;

@Component
public class CarServiceDao implements ICarService {

	private static final TypedQuery<SecurityQuestion> SecurityQuestion = null;
	@PersistenceContext
	private EntityManager entityManager;

	public CarServiceDao() {

	}

	@Override
	public int checkLogin(LoginDetails loginDetails) throws CarServiceException {
		int flag = 0;
		Query query = entityManager
				.createQuery("select l.id,l.password from LoginDetails l where l.id=? and l.password=? and l.type=?");
		query.setParameter(0, loginDetails.getId());
		query.setParameter(1, loginDetails.getPassword());
		query.setParameter(2, loginDetails.getType());
		List<LoginDetails> list = query.getResultList();
		if (list.size() != 0) {
			System.out.println("Logged in!!!");
			flag = 1;
		} else {
			System.err.println("User not available!!");
		}
		return flag;
	}

	@Transactional
	@Override
	public int saveUserDetails(UserDetails details) {
		entityManager.merge(details);
		int id = details.getUserId();
		String type = "user";
		String password = details.getPassword();
		LoginDetails loginDetails = new LoginDetails();
		loginDetails.setId(id);
		loginDetails.setPassword(password);
		loginDetails.setType(type);
		entityManager.merge(loginDetails);

		return 1;
	}

	@Transactional
	@Override
	public int saveServiceCentre(ServiceCentre centre) throws CarServiceException {
		entityManager.merge(centre);
		return 1;
	}

	@Override
	public List<ServiceCentre> getAllServiceCentre() throws CarServiceException {
		TypedQuery<ServiceCentre> query = entityManager.createQuery("select s from ServiceCentre s",
				ServiceCentre.class);
		List<ServiceCentre> list = query.getResultList();
		return list;
	}

	@Override
	public List<String> getServiceTypeById(int pid) throws CarServiceException {
		TypedQuery<String> query = (TypedQuery<String>) entityManager
				.createQuery("select st.typeName from ServiceSet ss join ss.type st where ss.centre.centreId=?");
		query.setParameter(0, pid);
		List<String> list = query.getResultList();
		System.out.println("  " + list);
		return list;
	}

	@Override
	public HashMap<String, List> getRequest() {
		int i = 0;
		HashMap<String, List> hashMap = new HashMap<>();

		TypedQuery<Integer> query = (TypedQuery<Integer>) entityManager.createQuery(
				"select ss.centre.centreId from ServiceRequest ss where ss.requestStatus=1 group by ss.centre.centreId");
		List<Integer> centreId = query.getResultList();

		for (i = 0; i < centreId.size(); i++) {

			Query query2 = entityManager.createQuery("select centreName from ServiceCentre where centreId=?");
			query2.setParameter(0, centreId.get(i));
			String centreName = (String) query2.getSingleResult();

			Query query1 = entityManager.createQuery(
					"select ss.requestTypes from ServiceRequest ss where ss.centre.centreId=? and ss.requestStatus=1");
			query1.setParameter(0, centreId.get(i));
			List typeNameList = query1.getResultList();

			hashMap.put(centreName, typeNameList);
		}

		System.out.println(hashMap);

		return hashMap;
	}

	@Transactional
	@Override
	public int responseService(String cname, int request) {
		System.out.println(cname);
		Query query = entityManager.createQuery("select centreId from ServiceCentre where centreName=?");
		query.setParameter(0, cname);
		int id = (int) query.getSingleResult();
		System.out.println(id);
		Query updatequery = entityManager
				.createQuery("update ServiceRequest ss set ss.requestStatus=? where ss.centre.centreId=?");
		updatequery.setParameter(0, request);
		updatequery.setParameter(1, id);
		updatequery.executeUpdate();
		return 1;
	}

	@Transactional
	@Override
	public int saveServiceType(String[] type, ServiceCentre centre) {

		System.out.println("length=" + type.length);
		for (int i = 0; i < type.length; i++) {
			int typeId = Integer.parseInt(type[i]);
			System.out.println("TYpeIUd:" + typeId);
			Query query = entityManager.createQuery("from ServiceType where typId=?");
			query.setParameter(0, typeId);

			ServiceType stype = (ServiceType) query.getSingleResult();
			ServiceSet serviceSet = new ServiceSet();

			serviceSet.setCentre(centre);
			serviceSet.setType(stype);

			entityManager.persist(serviceSet);
			System.out.println("type saved");
		}
		return 1;

	}

	@Override
	public ServiceCentre getAllServiceCentreById(int cid) throws CarServiceException {
		ServiceCentre centre = new ServiceCentre();
		TypedQuery<ServiceCentre> query = (TypedQuery<ServiceCentre>) entityManager
				.createQuery("select sc from ServiceCentre sc where sc.centreId=?");
		query.setParameter(0, cid);
		centre = query.getSingleResult();
		System.out.println("centre dao" + centre + " ends");
		return centre;
	}

	@Transactional
	@Override
	public int blockServiceCentre(int cid) throws CarServiceException {

		ServiceCentre centre = entityManager.find(ServiceCentre.class, cid);
		centre.setCentreAvailable("NotAvailable");
		entityManager.merge(centre);
		return 1;
	}

	@Transactional
	@Override
	public int removeServiceCentre(int cid) throws CarServiceException {
		ServiceCentre serviceCentre = entityManager.find(ServiceCentre.class, cid);
		entityManager.remove(serviceCentre);
		return 1;
	}

	@Transactional
	@Override
	public int removeServiceSet(int cid) throws CarServiceException {
		Query query = entityManager.createQuery("delete from ServiceSet ss where ss.centre.centreId=?");
		query.setParameter(0, cid);
		query.executeUpdate();
		return 1;
	}

	@Transactional
	@Override
	public int requestService(int cid, String[] typeName, LoginDetails details) {

		int i;
		double price = 0;
		String typeNames = "";
		ServiceCentre centre = new ServiceCentre();
		ServiceRequest request = new ServiceRequest();

		Query centrequery = entityManager.createQuery("from ServiceCentre where centreId=?");
		centrequery.setParameter(0, cid);
		centre = (ServiceCentre) centrequery.getSingleResult();
		System.out.println("centre    " + centre);
		Query typequery = entityManager.createQuery("select price from ServiceType where typeName=?");
		typequery.setParameter(0, typeName[0]);
		price += (double) typequery.getSingleResult();

		typeNames += typeName[0];

		for (i = 1; i < typeName.length; i++) {

			typeNames += "," + typeName[i];

			Query typequery1 = entityManager.createQuery("select price from ServiceType where typeName=?");
			typequery1.setParameter(0, typeName[i]);
			price += (double) typequery1.getSingleResult();
		}
		request.setCentre(centre);
		request.setDetails(details);
		request.setRequestPrice(price);
		request.setRequestTypes(typeNames);
		request.setRequestStatus(1);
		entityManager.persist(request);
		return 1;
	}

	@Override
	public List<ServiceRequest> requestStatus(int uid) {

		List<ServiceRequest> request = null;

		TypedQuery<ServiceRequest> query = entityManager
				.createQuery("select sr from ServiceRequest sr where sr.details.id=" + uid, ServiceRequest.class);
		request = query.getResultList();
		return request;

	}

	@Transactional
	@Override
	public int payment(int rid, LoginDetails details) {
		ServicePayment payment = new ServicePayment();
		ServiceRequest request = new ServiceRequest();
		ServiceHistory history = new ServiceHistory();
		LocalDate now = LocalDate.now();
		payment.setPaymentDate(now);
		payment.setPaymentStatus("success");
		payment.setDetails(details);
		TypedQuery<ServiceRequest> query = entityManager
				.createQuery("select sr from ServiceRequest sr where sr.requestId=" + rid, ServiceRequest.class);
		request = query.getSingleResult();
		payment.setRequest(request);
		entityManager.persist(payment);
		request.setRequestStatus(0);
		entityManager.merge(request);
		history.setPayment(payment);
		entityManager.merge(history);
		return 1;
	}

	@Transactional
	@Override
	public List<ServicePayment> history(int id) {

		List<ServicePayment> payment = null;
		TypedQuery<ServicePayment> query = entityManager
				.createQuery("select sp from ServicePayment sp where sp.details.id=" + id, ServicePayment.class);
		payment = query.getResultList();
		return payment;
	}

	@Transactional
	@Override
	public int securityAnswer(int securityId, UserDetails details) {

		System.out.println("securityId=" + securityId);
		SecurityQuestion securityQuestion = entityManager.find(SecurityQuestion.class, securityId);
		details.setSecurityQuestion(securityQuestion);
		entityManager.merge(details);

		return 1;
	}

	@Transactional
	@Override
	public UserDetails checkUser(int id) {

		UserDetails details = entityManager.find(UserDetails.class, id);
		if (details != null) {
			return details;
		}
		return null;
	}

	@Transactional
	@Override
	public UserDetails checkAnswer(int id, String answer) {

		UserDetails details = entityManager.find(UserDetails.class, id);
		String ans = details.getSecurityAnswer();
		if (ans.equals(answer)) {
			return details;
		} else
			return null;
	}

	@Transactional
	@Override
	public UserDetails saveNewPassword(int id, String password) {
		UserDetails details = entityManager.find(UserDetails.class, id);
		details.setPassword(password);
		entityManager.merge(details);

		LoginDetails details2 = entityManager.find(LoginDetails.class, id);
		details2.setPassword(password);
		entityManager.merge(details2);

		return details;
	}

}
