package com.cognizant.carservice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.carservice.exception.CarServiceException;

import com.cognizant.carservice.model.LoginDetails;
import com.cognizant.carservice.model.ServiceCentre;
import com.cognizant.carservice.model.ServicePayment;
import com.cognizant.carservice.model.ServiceRequest;
import com.cognizant.carservice.model.UserDetails;
import com.cognizant.carservice.service.CarService;

@Controller
public class CarServiceController {

	@Resource(name = "carService")
	CarService service;

	public CarServiceController() {

	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String home() {
		return "login";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String register() {
		return "signup";
	}

	@RequestMapping(value = "/back", method = RequestMethod.POST)
	public ModelAndView adminhome() throws CarServiceException {
		ModelAndView view = null;
		List<ServiceCentre> list = service.getAllServiceCentre();
		view = new ModelAndView("adminservice");
		view.addObject("service", list);
		return view;
	}

	@RequestMapping(value = "/backuser", method = RequestMethod.POST)
	public ModelAndView userhome() throws CarServiceException {
		ModelAndView view = null;
		List<ServiceCentre> list = service.getAllServiceCentre();
		view = new ModelAndView("userservice");
		view.addObject("service", list);
		return view;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(String id, String password, String type, HttpServletRequest request)
			throws CarServiceException {
		ModelAndView view = null;
		if (type.compareTo("admin") == 0) {
			LoginDetails details = new LoginDetails();
			details.setId(Integer.parseInt(id));
			details.setPassword(password);
			details.setType(type);
			int login = service.checkLogin(details);
			if (login == 1) {

				HttpSession session = request.getSession();
				session.setAttribute("user", details);
				List<ServiceCentre> list = service.getAllServiceCentre();
				view = new ModelAndView("adminservice");
				view.addObject("service", list);

			}
		}

		if (type.compareTo("user") == 0) {
			LoginDetails details = new LoginDetails();
			details.setId(Integer.parseInt(id));
			details.setPassword(password);
			details.setType(type);
			int login = service.checkLogin(details);
			if (login == 1) {
				HttpSession session = request.getSession();
				session.setAttribute("user", details);
				List<ServiceCentre> list = service.getAllServiceCentre();
				view = new ModelAndView("userservice");
				view.addObject("service", list);
			}

		}

		return view;

	}

	@RequestMapping(value = "/registerpage", method = RequestMethod.POST)
	public String registerPage() {
		return "register";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView register(String centreName, String filenames[], String centreAddress, String centreRating,
			String centrePrice, String centreNumber, String centreAvailable, String type[], ModelAndView view)
			throws CarServiceException {
		int id = 0;
		ServiceCentre centre = new ServiceCentre();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < filenames.length; i++) {
			sb.append(filenames[i]).append(",");
		}
		centre.setCentreName(centreName);
		centre.setCentreAddress(centreAddress);
		centre.setCentreAvailable(centreAvailable);
		centre.setCentreNumber(Long.parseLong(centreNumber));
		centre.setCentreRating(Float.parseFloat(centreRating));
		Random random = new Random();
		id = random.nextInt(900) + 100;
		centre.setCentreId(id);
		centre.setCentreImage(sb.toString());

		int addservice = service.saveServiceCentre(centre);
		int addtype = service.saveServiceType(type, centre);
		if (addservice == 1 && addtype == 1) {
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);

		}

		return view;
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView update(ServiceCentre centre, String[] type) throws CarServiceException {
		ModelAndView view = null;
		int addservice = service.saveServiceCentre(centre);
		int flag = service.removeServiceSet(centre.getCentreId());
		int addtype = service.saveServiceType(type, centre);
		if (addservice == 1 && addtype == 1 && flag == 1) {
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);

		}
		return view;
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public ModelAndView signup(String firstName, String lastName, String age, String mobile, String gender,
			String password, String securityAnswer, String securityQuestion) {
		ModelAndView view = null;
		UserDetails details = new UserDetails();
		Random random = new Random();
		int id = random.nextInt(900) + 100;
		details.setUserId(id);
		details.setFirstName(firstName);
		details.setLastName(lastName);
		details.setAge(Integer.parseInt(age));
		details.setGender(gender);
		details.setMobile(Long.parseLong(mobile));
		details.setPassword(password);
		details.setSecurityAnswer(securityAnswer);
		int securityId = Integer.parseInt(securityQuestion);
		int set = service.securityAnswer(securityId, details);
		int count = service.saveUserDetails(details);
		if (count == 1) {
			view = new ModelAndView("login");
			view.addObject("message", "your user id is " + id);
		}

		return view;
	}

	@RequestMapping(value = "/viewcentre", method = RequestMethod.POST)
	public ModelAndView view(String centreId, String Show, String Remove, String Block, String Update)
			throws CarServiceException {

		ModelAndView view = null;
		int cid = Integer.parseInt(centreId);
		int flag, flag1;

		if (Show != null) {
			List<String> serviceType = service.getServiceTypeById(cid);
			ServiceCentre serviceCentre = service.getAllServiceCentreById(cid);
			view = new ModelAndView("viewcentre");
			view.addObject("type", serviceType);
			view.addObject("service", serviceCentre);

		}
		if (Block != null) {
			flag = service.blockServiceCentre(cid);
			if (flag == 1) {
				List<ServiceCentre> list = service.getAllServiceCentre();
				view = new ModelAndView("adminservice");
				view.addObject("service", list);
			}

		}
		if (Remove != null) {
			flag1 = service.removeServiceSet(cid);
			flag = service.removeServiceCentre(cid);
			if (flag == 1 && flag1 == 1) {
				List<ServiceCentre> list = service.getAllServiceCentre();
				view = new ModelAndView("adminservice");
				view.addObject("service", list);
			}

		}
		if (Update != null) {

			List<String> serviceType = service.getServiceTypeById(cid);
			ServiceCentre serviceCentre = service.getAllServiceCentreById(cid);
			view = new ModelAndView("updatecentre");
			view.addObject("type", serviceType);
			view.addObject("service", serviceCentre);

		}

		return view;

	}

	@RequestMapping(value = "/userview", method = RequestMethod.POST)
	public ModelAndView userview(String centreId, String Show, HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		int cid = Integer.parseInt(centreId);

		if (Show != null) {
			List<String> serviceType = service.getServiceTypeById(cid);
			ServiceCentre serviceCentre = service.getAllServiceCentreById(cid);
			HttpSession httpSession = request.getSession(false);
			LoginDetails details = (LoginDetails) httpSession.getAttribute("user");
			view = new ModelAndView("takeservice");
			view.addObject("type", serviceType);
			view.addObject("service", serviceCentre);
			view.addObject("name", details.getId());

		}
		return view;

	}

	@RequestMapping(value = "/request", method = RequestMethod.POST)
	public ModelAndView request(String centreId, String[] type, HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		HttpSession httpSession = request.getSession(false);
		LoginDetails details = (LoginDetails) httpSession.getAttribute("user");
		service.requestService(Integer.parseInt(centreId), type, details);
		List<ServiceCentre> list = service.getAllServiceCentre();
		view = new ModelAndView("userservice");
		view.addObject("service", list);
		view.addObject("message", "request sent successfully.Please wait for admin to respond");

		return view;

	}

	@RequestMapping(value = "/response", method = RequestMethod.POST)
	public ModelAndView response() throws CarServiceException {

		ModelAndView view = null;
		HashMap<String, List> map = service.getRequest();
		view = new ModelAndView("request");
		view.addObject("request", map);

		return view;

	}

	@RequestMapping(value = "/payment", method = RequestMethod.POST)
	public ModelAndView payment(String requestId, HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		HttpSession httpSession = request.getSession(false);
		LoginDetails details = (LoginDetails) httpSession.getAttribute("user");
		service.payment(Integer.parseInt(requestId), details);
		List<ServiceCentre> list = service.getAllServiceCentre();
		view = new ModelAndView("userservice");
		view.addObject("service", list);
		view.addObject("message", "Payment is successfull");
		return view;

	}

	@RequestMapping(value = "/requestStatus", method = RequestMethod.POST)
	public ModelAndView requestStatus(HttpServletRequest request) throws CarServiceException {

		ModelAndView view = null;
		HttpSession httpSession = request.getSession(false);
		LoginDetails details = (LoginDetails) httpSession.getAttribute("user");
		List<ServiceRequest> list = service.requestStatus(details.getId());
		view = new ModelAndView("response");
		view.addObject("requestList", list);

		return view;

	}

	@RequestMapping(value = "/history", method = RequestMethod.GET)
	public ModelAndView history(HttpServletRequest request) throws CarServiceException {
		ModelAndView view = null;
		HttpSession httpSession = request.getSession(false);
		LoginDetails details = (LoginDetails) httpSession.getAttribute("user");
		List<ServicePayment> list = service.history(details.getId());

		view = new ModelAndView("history");
		view.addObject("historyList", list);

		return view;

	}

	@RequestMapping(value = "/acceptordecline", method = RequestMethod.POST)
	public ModelAndView acceptordecline(String centreName, String Accept, String Reject) throws CarServiceException {

		ModelAndView view = null;
		if (Accept != null) {
			service.responseService(centreName, 2);
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);
		}
		if (Reject != null) {
			service.responseService(centreName, 3);
			List<ServiceCentre> list = service.getAllServiceCentre();
			view = new ModelAndView("adminservice");
			view.addObject("service", list);
		}

		return view;

	}

	@RequestMapping(value = "/LogoutController", method = RequestMethod.GET)
	public String logoutController(ModelAndView modelAndView, HttpServletRequest request) throws CarServiceException {

		HttpSession httpSession = request.getSession(false);
		httpSession.invalidate();
		return "redirect:home";
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	public String forgotPassword() {

		return "forgotPassword";
	}

	@RequestMapping(value = "/checkUsername", method = RequestMethod.GET)
	public ModelAndView checkUser(String id) {
		ModelAndView view = null;
		int userid = Integer.parseInt(id);
		UserDetails details = service.checkUser(userid);
		if (details != null) {
			view = new ModelAndView("newPassword");
			view.addObject("userDetails", details);
			return view;
		} else {
			view = new ModelAndView("forgotPassword");
			view.addObject("message", "Username not Exists");
			return view;
		}

	}

	@RequestMapping(value = "/setPassword", method = RequestMethod.GET)
	public ModelAndView setPassword(String userId, String securityAnswer) {
		ModelAndView view = null;
		int id = Integer.parseInt(userId);
		UserDetails details = service.checkAnswer(id, securityAnswer);
		if (details != null) {
			view = new ModelAndView("reenterPassword");
			view.addObject("userDetails", details);
			return view;
		} else {
			view = new ModelAndView("forgotPassword");
			view.addObject("message", "Your answer is Wrong");
			return view;
		}

	}

	@RequestMapping(value = "/savePassword", method = RequestMethod.POST)
	public ModelAndView savenewPassword(String userId, String password, String password1) {
		ModelAndView view = null;
		int id = Integer.parseInt(userId);
		if (password.equals(password1)) {
			UserDetails details = service.saveNewPassword(id, password);
			if (details != null) {
				view = new ModelAndView("login");
				view.addObject("message", "Password set Sucessfully");
			}
			return view;
		} else {
			view = new ModelAndView("forgotPassword");
			view.addObject("message", "Password mismatching");
			return view;
		}

	}

}
