package com.cognizant.carservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "service_centre")
public class ServiceCentre {

	@Id
	@Column(name = "sc_id")
	private int centreId;
	@Column(name = "sc_name")
	private String centreName;
	@Column(name = "sc_address")
	private String centreAddress;
	@Column(name = "sc_number")
	private long centreNumber;
	@Column(name = "sc_available")
	private String centreAvailable;
	@Column(name = "sc_rating")
	private float centreRating;
	@Column(name = "sc_img")
	private String centreImage;

	public ServiceCentre() {

	}

	public ServiceCentre(int centreId, String centreName, String centreAddress, long centreNumber,
			String centreAvailable, float centreRating, String centreImage) {
		super();
		this.centreId = centreId;
		this.centreName = centreName;
		this.centreAddress = centreAddress;
		this.centreNumber = centreNumber;
		this.centreAvailable = centreAvailable;
		this.centreRating = centreRating;
		this.centreImage = centreImage;
	}

	public int getCentreId() {
		return centreId;
	}

	public void setCentreId(int centreId) {
		this.centreId = centreId;
	}

	public String getCentreName() {
		return centreName;
	}

	public void setCentreName(String centreName) {
		this.centreName = centreName;
	}

	public String getCentreAddress() {
		return centreAddress;
	}

	public void setCentreAddress(String centreAddress) {
		this.centreAddress = centreAddress;
	}

	public long getCentreNumber() {
		return centreNumber;
	}

	public void setCentreNumber(long centreNumber) {
		this.centreNumber = centreNumber;
	}

	public String getCentreAvailable() {
		return centreAvailable;
	}

	public void setCentreAvailable(String centreAvailable) {
		this.centreAvailable = centreAvailable;
	}

	public float getCentreRating() {
		return centreRating;
	}

	public void setCentreRating(float centreRating) {
		this.centreRating = centreRating;
	}

	public String getCentreImage() {
		return centreImage;
	}

	public void setCentreImage(String centreImage) {
		this.centreImage = centreImage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((centreAddress == null) ? 0 : centreAddress.hashCode());
		result = prime * result + ((centreAvailable == null) ? 0 : centreAvailable.hashCode());
		result = prime * result + centreId;
		result = prime * result + ((centreImage == null) ? 0 : centreImage.hashCode());
		result = prime * result + ((centreName == null) ? 0 : centreName.hashCode());
		result = prime * result + (int) (centreNumber ^ (centreNumber >>> 32));
		result = prime * result + Float.floatToIntBits(centreRating);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceCentre other = (ServiceCentre) obj;
		if (centreAddress == null) {
			if (other.centreAddress != null)
				return false;
		} else if (!centreAddress.equals(other.centreAddress))
			return false;
		if (centreAvailable == null) {
			if (other.centreAvailable != null)
				return false;
		} else if (!centreAvailable.equals(other.centreAvailable))
			return false;
		if (centreId != other.centreId)
			return false;
		if (centreImage == null) {
			if (other.centreImage != null)
				return false;
		} else if (!centreImage.equals(other.centreImage))
			return false;
		if (centreName == null) {
			if (other.centreName != null)
				return false;
		} else if (!centreName.equals(other.centreName))
			return false;
		if (centreNumber != other.centreNumber)
			return false;
		if (Float.floatToIntBits(centreRating) != Float.floatToIntBits(other.centreRating))
			return false;
		return true;
	}

}
